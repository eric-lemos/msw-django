from flask import Flask, Response, request
from flask_restful import Resource, Api
from library import Simulator
from waitress import serve
from time import sleep
from json import dumps
import logging

logging.basicConfig(level=logging.INFO)
wsgi_app = Flask(__name__)
streaming = Api(wsgi_app)
simulator = Simulator(4)

class overview(Resource):
    def get(self):
        def event():
            while(True):
                yield(f"data: {simulator.overview()} \n\n")
                sleep(0.2)
        return Response(event(), mimetype="text/event-stream")

class audit(Resource):
    def get(self):
        http_args = request.args.getlist("m")
        def event():
            while(True):
                yield(f"data: {simulator.audit(http_args)} \n\n")
                sleep(1)
        return Response(event(), mimetype="text/event-stream")

class zabbix(Resource):
    def get(self, id):
        return simulator.zabbix(id)

streaming.add_resource(zabbix, "/msw/api/zabbix/state/<int:id>")
streaming.add_resource(overview, "/msw/stream/overview")
streaming.add_resource(audit, "/msw/stream/audit/")

if(__name__ == "__main__"):
    serve(wsgi_app, listen="*:5000", threads=12)