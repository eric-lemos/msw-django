from random import SystemRandom
from json import dumps

class Simulator:
    def __init__(self, devices):
        self.num_devices = devices+1
        self.num_receivers = 0
        self.receivers = []
        self.devices = []
        self.init()

    def init(self):
        reference = 0

        for id in range(1, self.num_devices):
            self.devices.append(id)

            for receive in range(1, id+1):
                rx1 = receive + reference
                rx2 = receive + receive
            reference += 1

            self.receivers.append(rx1)
            self.receivers.append(rx2)

        self.num_receivers = len(self.receivers)+1     

    @staticmethod
    def detail(mic_id):
        return "rx2" if((mic_id % 2) == 0) else "rx1"

    #===================== OVERVIEW =====================#
    def overview(self):
        results = []
        count = 0

        for receive_id in range(1, self.num_receivers):
            if((receive_id % 2) == 0):
                rx1 = receive_id-1
                rx2 = receive_id
                
                dictionary = {

                    "device": {
                        "id": self.devices[count],
                        "model": "em6000",
                        "alias": f"TEST-EM6000-{self.devices[count]}",
                        "ping": "connected",
                    },

                    "receivers": {
                        "rx1":  {
                            "id": rx1,
                            "dva": 1,
                            "dvb": 1,
                            "name": f"rx-{rx1}-name",
                            "alias": f"rx-{rx1}-alias",
                            "status": [],
                            "battery": [70, "10:20"],
                            "carrier": 480500,
                            "warnings": [],
                            "is_online": True,
                        },

                        "rx2":  {
                            "id": rx2,
                            "dva": 1,
                            "dvb": 1,
                            "name": f"rx-{rx2}-name",
                            "alias": f"rx-{rx2}-alias",
                            "status": [],
                            "battery": [30, "05:11"],
                            "carrier": 430100,
                            "warnings": [],
                            "is_online": True,
                        }
                    }
                }

                count += 1
                # json_data = dumps(dictionary)
                # results.append(json_data)
                results.append(dictionary)
        return dumps(results)

    #===================== AUDIT ========================#
    @staticmethod
    def percent(value, min, max):
        return round( ((value - min)/(max - min))*100, 2)

    @staticmethod
    def lqi(value): return round((value/255)*100, 0)

    @staticmethod
    def dBFS(value): return (((value+1)/2)-128)

    @staticmethod
    def dBm(value): return ((value-255)/2)

    def random_audio(self):
        random = SystemRandom()
        audio_dbfs = self.dBFS(random.randint(200, 250))
        audio_perc = self.percent(audio_dbfs, -40, 0)
        return [audio_dbfs, audio_perc]

    def random_rf(self):
        random = SystemRandom()
        rf_dbm = self.dBm(random.randint(80, 150))
        rf_per = self.percent(rf_dbm, -100, -60)
        return [rf_dbm, rf_per]

    def audit(self, http_args):
        results = []
        count = 0
        
        for receive_id in range(1, self.num_receivers):
            for mic_id in http_args:
                mic_id = int(mic_id)

                if(mic_id and (mic_id == receive_id)):
                    audio = self.random_audio()
                    rfa = self.random_rf()
                    rfb = self.random_rf()

                    dictonary = {

                        "device": {
                            "id": self.devices[count],
                            "model": "em6000",
                            "alias": f"TEST-EM6000-{self.devices[count]}",
                            "host": f"192.168.0.{self.devices[count]}",
                            "port": 6970,
                            "ping": "connected",

                            "feature": {
                                "min_gain": -10,
                                "max_gain": 18
                            },

                            "system": {
                                "name": f"Digital6000-{mic_id}",
                                "clockFreq": "48000 Hz",
                                "clock": 1
                            }
                        },

                        "mic":  {
                            "id": mic_id,
                            "name": f"rx-{mic_id}-name",
                            "alias": f"rx-{mic_id}-alias",
                            "detail": self.detail(mic_id),
                            "battery": [70, "10:20"],
                            "capsule": "unknown",
                            "carrier": 480500,
                            "paudio": audio[1],
                            "audio": audio[0],
                            "rfa_p": rfa[1],
                            "rfb_p": rfb[1],
                            "rfa": rfa[0],
                            "rfb": rfb[0],
                            "mute": 0,
                            "lqi": 70,
                            "dva": 1,
                            "dvb": 1,
                            "status": [],
                            "warnings": [],
                            "is_online": True,
                        },
                    }
                    
                    count += 1
                    #json_data = dumps(dictonary)
                    #results.append(json_data)
                    results.append(dictonary)
        return dumps(results)

    #===================== ZABBIX =======================#
    def zabbix(self, mic_id):
        results = []
        count = 0

        for receive_id in range(1, self.num_receivers):
            if(mic_id == receive_id):
                audio = self.random_audio()
                rfa = self.random_rf()
                rfb = self.random_rf()

                dictonary = {

                    "device": {
                        "id": mic_id,
                        "model": "em6000",
                        "alias": f"TEST-EM6000-{self.devices[count]}",
                        "host": f"192.168.0.{self.devices[count]}",
                        "port": 6970,
                        "ping": "connected",

                        "feature": {
                            "min_gain": -10,
                            "max_gain": 18
                        },

                        "system": {
                            "name": f"Digital6000-{mic_id}",
                            "clockFreq": "48000 Hz",
                            "clock": 1
                        }
                    },

                    "mic":  {
                        "id": mic_id,
                        "name": f"rx-{mic_id}-name",
                        "alias": f"rx-{mic_id}-alias",
                        "detail": self.detail(mic_id),
                        "battery": [70, "10:20"],
                        "capsule": "unknown",
                        "carrier": 480500,
                        "paudio": audio[1],
                        "audio": audio[0],
                        "rfa_p": rfa[1],
                        "rfb_p": rfb[1],
                        "rfa": rfa[0],
                        "rfb": rfb[0],
                        "mute": 0,
                        "lqi": 80,
                        "dva": 1,
                        "dvb": 1,
                        "status": [],
                        "warnings": [],
                        "is_online": True,
                    },
                }

                count += 1
                #json_data = dumps(dictonary)
                #results.append(json_data)
                results.append(dictonary)
        return results

if(__name__ == "__main__"):
    s = Simulator(4)
    #print(dumps(s.zabbix(1), indent=4))

    r = SystemRandom()
    print(r.randint(0, 255))